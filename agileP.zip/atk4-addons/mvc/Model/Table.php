<?php
class Model_Table extends Model_MVCTable {}
