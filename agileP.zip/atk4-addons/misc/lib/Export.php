<?php
/* to enable compatbility mode:
 * redefine class Export extends Export_Compat {}
 */
namespace misc;
class Export extends Export_Advanced {}
