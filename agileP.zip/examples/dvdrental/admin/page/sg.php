<?php
class page_sg extends Page_SchemaGenerator {
}
